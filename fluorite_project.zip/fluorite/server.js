require('dotenv').config();
const express = require('express');
const multer = require('multer');
const fs = require('fs');
const fetch = require('node-fetch');
const path = require('path');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Config
const PORT = process.env.PORT || 3000;
const BOT_TOKEN = process.env.BOT_TOKEN; // set in .env
const CHAT_ID = process.env.CHAT_ID;     // set in .env
const AUTO_APPROVE = process.env.AUTO_APPROVE === 'true';
const DATA_FILE = path.join(__dirname, 'data.json');
const UPLOAD_DIR = path.join(__dirname, 'uploads');

if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// Multer setup
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname) || '.jpg';
    const name = 'pay_' + Date.now() + ext;
    cb(null, name);
  }
});
const upload = multer({ storage });

// load/save helper
function loadData() {
  if (!fs.existsSync(DATA_FILE)) return { users: {}, payments: [], keys: [] };
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE,'utf8'));
  } catch(e){
    return { users: {}, payments: [], keys: [] };
  }
}
function saveData(d){ fs.writeFileSync(DATA_FILE, JSON.stringify(d, null, 2), 'utf8'); }

// send message to telegram (text)
async function sendTelegramMessage(text) {
  if(!BOT_TOKEN || !CHAT_ID) {
    console.warn('BOT_TOKEN or CHAT_ID not configured.');
    return;
  }
  const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`;
  await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type':'application/json' },
    body: JSON.stringify({ chat_id: CHAT_ID, text, parse_mode: 'HTML' })
  });
}

// send photo to telegram
async function sendTelegramPhoto(photoPath, caption){
  if(!BOT_TOKEN || !CHAT_ID) {
    console.warn('BOT_TOKEN or CHAT_ID not configured.');
    return;
  }
  const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendPhoto`;
  const FormData = require('form-data');
  const form = new FormData();
  form.append('chat_id', CHAT_ID);
  form.append('caption', caption || '');
  form.append('photo', fs.createReadStream(photoPath));
  await fetch(url, { method: 'POST', body: form });
}

/* ============================
   Endpoints
   ============================ */

// Health
app.get('/ping', (req,res)=> res.json({ok:true}));

// REGISTER / APLIKIM -> dërgon mesazh në Telegram para login
app.post('/apply', async (req,res)=>{
  const { username, reason } = req.body;
  if(!username || !reason) return res.status(400).json({error:'username dhe reason required'});
  const msg = `<b>Aplicim i ri</b>\nUser: ${username}\nArsye: ${reason}\nTime: ${new Date().toISOString()}`;
  await sendTelegramMessage(msg);
  return res.json({ok:true, msg:'Aplikimi u dergua'});
});

// SIMPLE LOGIN (demo)
app.post('/login', (req,res)=>{
  const { username, password } = req.body;
  if(username === 'fluoritebroly' && password === 'fluorite1') {
    return res.json({ok:true, username, token: 'demo-session-token'});
  }
  return res.status(401).json({error:'invalid credentials'});
});

// UPLOAD TOPUP (photo). Sends photo to Telegram and records payment
app.post('/topup', upload.single('screenshot'), async (req,res)=>{
  try{
    const { username, amount, txid, autoApprove } = req.body;
    if(!username || !amount || !txid) {
      return res.status(400).json({error:'username, amount, txid required'});
    }
    const file = req.file;
    const data = loadData();
    if(!data.users[username]) data.users[username] = { balance: 0, history: [] };

    const payment = {
      id: 'pay_' + Date.now(),
      username,
      amount: Number(amount),
      txid,
      file: file ? file.filename : null,
      status: AUTO_APPROVE || autoApprove === 'true' ? 'approved' : 'pending',
      ts: new Date().toISOString()
    };
    data.payments.unshift(payment);

    if(payment.status === 'approved'){
      data.users[username].balance = Number((Number(data.users[username].balance) + Number(amount)).toFixed(2));
      data.users[username].history = data.users[username].history || [];
      data.users[username].history.unshift({type:'topup', amount: Number(amount), txid, ts: payment.ts});
    }

    saveData(data);

    const caption = `<b>TopUp Request</b>\nUser: ${username}\nAmount: ${amount} €\nTxID: ${txid}\nStatus: ${payment.status}\nID: ${payment.id}`;
    if(file){
      await sendTelegramPhoto(path.join(UPLOAD_DIR, file.filename), caption);
    } else {
      await sendTelegramMessage(caption);
    }

    return res.json({ok:true, payment});
  } catch(e){
    console.error(e);
    return res.status(500).json({error:'internal'});
  }
});

// Admin endpoint to approve a payment
app.post('/admin/approve', (req,res)=>{
  const { paymentId } = req.body;
  const data = loadData();
  const p = data.payments.find(x=>x.id === paymentId);
  if(!p) return res.status(404).json({error:'payment not found'});
  if(p.status === 'approved') return res.json({ok:true, msg:'already approved'});
  p.status = 'approved';
  if(!data.users[p.username]) data.users[p.username] = { balance:0, history:[] };
  data.users[p.username].balance = Number((Number(data.users[p.username].balance) + Number(p.amount)).toFixed(2));
  data.users[p.username].history.unshift({type:'topup', amount: p.amount, txid: p.txid, ts: new Date().toISOString()});
  saveData(data);
  sendTelegramMessage(`<b>Payment approved</b>\nID: ${paymentId}\nUser: ${p.username}\nAmount: ${p.amount} €`);
  return res.json({ok:true});
});

// Get user dashboard (balance, history)
app.get('/user/:username', (req,res)=>{
  const data = loadData();
  const u = data.users[req.params.username] || { balance:0, history:[] };
  return res.json({ok:true, user: u});
});

/* ============= KEY GENERATION endpoint (placeholder) =============
   Server-side placeholder for secure KeyAuth integration.
*/
app.post('/createKey', (req,res)=>{
  const { username, days } = req.body;
  if(!username || !days) return res.status(400).json({error:'username, days required'});

  const key = 'FL-' + Math.random().toString(36).substr(2,12).toUpperCase();
  const data = loadData();
  data.keys.unshift({ key, username, days, created: new Date().toISOString(), expires: new Date(Date.now() + days*24*60*60*1000).toISOString() });
  saveData(data);

  sendTelegramMessage(`<b>Key generated</b>\nUser: ${username}\nKey: <code>${key}</code>\nDays: ${days}`);
  return res.json({ok:true, key});
});

app.listen(PORT, ()=> {
  console.log(`Server listening on ${PORT}`);
  if(!BOT_TOKEN || !CHAT_ID) console.warn('BOT_TOKEN or CHAT_ID missing in .env — Telegram messages will not be sent.');
});
